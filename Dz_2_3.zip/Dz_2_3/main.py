import math

name = "Tatiana"
print(name)

x = float(input("Введите число"))
y = float(input("Введите число"))
z = float(input("Введите число"))

m = math.log10(y**(-math.sqrt(abs(x))))*(x-y/2)+math.sin(math.atan(z))**2
print(m)


import math
print("Введите x,y,z")
try:
    x = float(input("Введите число"))
    y = float(input("Введите число"))
    z = float(input("Введите число"))
except ValueError:
    print("Введите числа, а не буквы")
    x = float(input("Введите число"))
    y = float(input("Введите число"))
    z = float(input("Введите число"))

if (x < 0) and (x > 0) and (y < 0) and (y > 0) and (z < 0) and (z > 0):
    print("Числа подходят")
else:
    print("Число не подходит, введите все подходящие")
    x = float(input("Введите число"))
    y = float(input("Введите число"))
    z = float(input("Введите число"))

m = math.log10(y**(-math.sqrt(abs(x))))*(x-y/2)+math.sin(math.atan(z))**2
print(m)

